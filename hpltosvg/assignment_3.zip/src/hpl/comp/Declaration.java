package hpl.comp;


import java.lang.Override;

public abstract class Declaration implements CompilerResult
{
	//Sets the id for any assignment
	public abstract void setId(String id);

}